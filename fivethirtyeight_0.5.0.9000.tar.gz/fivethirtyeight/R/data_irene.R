#' Riddler Nation - Castles Puzzle

#' @description This contains the data behind the submissions for three rounds of the castles strategy puzzles: 
#'
#' Can You Rule Riddler Nation? \url{https://fivethirtyeight.com/features/can-you-rule-riddler-nation/}
#'
#' The Battle For Riddler Nation, Round 2 \url{http://fivethirtyeight.com/features/the-battle-for-riddler-nation-round-2/}
#'
#' Are You The Best Warlord? \url{https://fivethirtyeight.com/features/are-you-the-best-warlord/}
#' 
#'
#' Readers were asked to submit a strategy for the following “Colonel Blotto”-style game: 
#'
#'  
#' In a distant, war-torn land, there are 10 castles. There are two warlords: you and your archenemy. Each castle has its own strategic value for a would-be conqueror. Specifically, the castles are worth 1, 2, 3, …, 9, and 10 victory points. You and your enemy each have 100 soldiers to distribute, any way you like, to fight at any of the 10 castles. Whoever sends more soldiers to a given castle conquers that castle and wins its victory points. If you each send the same number of troops, you split the points. You don’t know what distribution of forces your enemy has chosen until the battles begin. Whoever wins the most points wins the war. 
#'
#' Submit a plan distributing your 100 soldiers among the 10 castles. Once I receive all your battle plans, I’ll adjudicate all the possible one-on-one matchups. Whoever wins the most wars wins the battle royale and is crowned king or queen of Riddler Nation!

#' @format A data frame with 13870 rows representing users, and 3 variables:
#' \describe{
#'   \item{user}{ID for the user who submitted the response}
#'   \item{castle}{which castle the user chose}
#'   \item{number_of_soldiers}{the number of soldiers they assigned to the castle}
#'   \item{strategy}{their reasoning/strategy for the number of soldiers}
#'   }

"castle_solutions"




#' Riddler Nation - Castles Puzzle 2

#' @description This contains the data behind the submissions for three rounds of the castles strategy puzzles: 
#'
#' The Battle For Riddler Nation, Round 2 \url{http://fivethirtyeight.com/features/the-battle-for-riddler-nation-round-2/} 
#'
#' Readers were asked to submit a strategy for the following “Colonel Blotto”-style game: 
#'
#'  
#' In a distant, war-torn land, there are 10 castles. There are two warlords: you and your archenemy. Each castle has its own strategic value for a would-be conqueror. Specifically, the castles are worth 1, 2, 3, …, 9, and 10 victory points. You and your enemy each have 100 soldiers to distribute, any way you like, to fight at any of the 10 castles. Whoever sends more soldiers to a given castle conquers that castle and wins its victory points. If you each send the same number of troops, you split the points. You don’t know what distribution of forces your enemy has chosen until the battles begin. Whoever wins the most points wins the war. 
#'
#' Submit a plan distributing your 100 soldiers among the 10 castles. Once I receive all your battle plans, I’ll adjudicate all the possible one-on-one matchups. Whoever wins the most wars wins the battle royale and is crowned king or queen of Riddler Nation!

#' @format A data frame with 9320 rows representing users, and 3 variables:
#' \describe{
#'   \item{user}{ID for the user who submitted the response}
#'   \item{castle}{which castle the user chose}
#'   \item{number_of_soldiers}{the number of soldiers they assigned to the castle}
#'   \item{strategy}{their reasoning/strategy for the number of soldiers}
#'   }
#'   
"castle_solutions_2"




#' Riddler Nation - Castles Puzzle Final

#' @description This contains the data behind the submissions for three rounds of the castles strategy puzzles: 

#' Are You The Best Warlord? \url{https://fivethirtyeight.com/features/are-you-the-best-warlord/}
#' 
#'
#' Readers were asked to submit a strategy for the following “Colonel Blotto”-style game: 
#'
#'  
#' In a distant, war-torn land, there are 10 castles. There are two warlords: you and your archenemy. Each castle has its own strategic value for a would-be conqueror. Specifically, the castles are worth 1, 2, 3, …, 9, and 10 victory points. You and your enemy each have 100 soldiers to distribute, any way you like, to fight at any of the 10 castles. Whoever sends more soldiers to a given castle conquers that castle and wins its victory points. If you each send the same number of troops, you split the points. You don’t know what distribution of forces your enemy has chosen until the battles begin. Whoever wins the most points wins the war. 
#'
#' Submit a plan distributing your 100 soldiers among the 10 castles. Once I receive all your battle plans, I’ll adjudicate all the possible one-on-one matchups. Whoever wins the most wars wins the battle royale and is crowned king or queen of Riddler Nation!

#' @format A data frame with 14660 rows representing users, and 3 variables:
#' \describe{
#'   \item{user}{ID for the user who submitted the response}
#'   \item{castle}{which castle the user chose}
#'   \item{number_of_soldiers}{the number of soldiers they assigned to the castle}
#'   \item{strategy}{their reasoning/strategy for the number of soldiers}
#'   }
#'   
"castle_solutions_3"






