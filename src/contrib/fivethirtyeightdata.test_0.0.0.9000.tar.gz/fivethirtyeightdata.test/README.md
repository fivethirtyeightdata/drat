
<!-- README.md is generated from README.Rmd. Please edit that file -->

# fivethirtyeightdata.test

<!-- badges: start -->

[![Travis build
status](https://travis-ci.com/mariumtapal/fivethirtyeightdata.test.svg?branch=master)](https://travis-ci.com/mariumtapal/fivethirtyeightdata.test)
<!-- badges: end -->

`fivethirtyeightdata.test` is an add-on R data package that contains the
large datasets not found in the original `fivethirtyeight` package via a
drat repository , published by FiveThirtyEight .

## Installation

You can install the latest version from [GitHub](https://github.com/)
with:

``` r
# install.packages("devtools")
devtools::install_github("mariumtapal/fivethirtyeightdata.test")
```
