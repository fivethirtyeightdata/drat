library(testthat)
library(fivethirtyeightdata.test)

test_check("fivethirtyeightdata.test")
