library(testthat)
library(fivethirtyeightdata)

test_check("fivethirtyeightdata")
