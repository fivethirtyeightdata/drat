# fivethirtyeightdata 0.1.0

* Released initial version of the package
* Contains 19 large datasets that exceeded CRAN size limitions in the `fivethirtyeight` package
* Inludeded all user-contributed vignettes from datasets in both `fivethirtyeight` and `fivethirtyeightdata` packages 
